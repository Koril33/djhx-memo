# Logo 素材包 v1

「墨盘 · 日蚀 · 墨滴」——一滴墨里藏着一轮将出的日。

本包包含各端图标(桌面、Android、Web、托盘、通知)、5 套配色、矢量母版、预览图,以及可重新生成全部素材的脚本。

- **程序同学**:直接跳到 [第 5 节 各端接入](#5-各端接入程序同学)。
- **美术同学**:重点看 [第 2、3、4 节](#2-设计理念) 和 [第 7 节 待美术确认](#7-待美术确认)。
- **所有人**:先打开 `preview/colorways-overview.png` 选配色。

---

## 1. 先做决定:选哪套配色

5 套配色共用同一套几何,只换颜色,所以**可以先用任意一套开发,最后再替换整个 `colorways/<名字>/` 目录**,不用改任何代码。

| 目录名 | 名称 | 底色 | 墨盘 | 墨滴 | 适合 |
|---|---|---|---|---|---|
| `sunrise` | 朝暾 | 渐变 `#F2B45C → #E8734A` | `#14161A` | `#F6F1E7` | 最贴近“墨中出日”,主屏最醒目 |
| `ink-night` | 墨夜 | `#0E0F11` | `#262B33` | `#F6F1E7` | 深色系统、深色 UI,最克制 |
| `ink-paper` | 宣纸 | `#F7F4EE` | `#14161A` | `#F7F4EE`(镂空) | 浅色场景、文档、印刷 |
| `vermilion` | 朱砂 | `#F7F4EE` | `#14161A` | `#C0392B` | 像盖了一枚印,红色只占极小面积 |
| `indigo` | 靛青 | `#EEF1F6` | `#1B2A49` | `#EEF1F6`(镂空) | 偏工具、偏理性,与暖色图标区分明显 |

**建议(供决策,不是定论)**:应用图标用 `sunrise`,因为手机主屏和任务栏上深色图标很多,暖色底最容易被找到;`ink-night` 作为备选。`ink-paper` 和 `vermilion` 更适合文档页脚、名片、周边。最终由你们定。

色值同时提供了机器可读版本:`tokens/colors.json`、`tokens/colors.css`。

---

## 2. 设计理念

**一句话叙事:光从墨里长出来。**

墨代表书写、记录、沉淀;日代表看见、洞见、被照亮。对一个备忘录工具来说,你投入的是墨,得到的是光。

图形由三个元素构成,每一个都对应一层含义:

1. **墨盘**:一个实心圆,是“墨”,也是“日”的本体。
2. **日蚀缺口**:右上角被另一个圆咬掉一块,像日蚀。缺口是“光”将要出来的方向,同时让圆形剪影有了辨识度。
3. **墨滴**:盘心一滴反色的墨,上端是尖角,下端圆润,中间平滑过渡。它来自钢笔笔尖的“气孔 + 中缝”,是书写的起点,也是整个图形的视觉落点。

**为什么墨滴是尖头朝上**:尖头指向右上的缺口,和光的方向呼应,读起来是“墨在向着光生长”。倒过来会变成一滴正在落下的水,叙事就变了。

**为什么要圆润**:缺口的两个转角、墨滴的圆头与过渡都做了圆角。工具类产品容易显得冷,圆润让它更亲和,也更耐看。

**设计演进(供追溯)**:最初是“墨盘 + 笔锋弧 + 小墨点”,笔锋弧在小尺寸下像划痕,去掉;随后墨点换成水滴,再换成钢笔气孔和中缝;最后把气孔和中缝合成一滴墨滴。

---

## 3. 图形构造

画布 24 × 24 单位,以下是母版的精确参数。美术如果要在设计软件中重画,按这些数字来。

### 3.1 墨盘与缺口

| 元素 | 参数 |
|---|---|
| 墨盘 | 圆心 (12, 11.8),半径 8.2 |
| 缺口圆 | 圆心 (18.93, 4.87),半径 5.0(沿右上 45° 方向,距盘心 9.8) |
| 缺口转角圆角 | 半径 1.0,作用于缺口与盘沿相交的两个转角 |
| 光学修正 | 整体上移 0.2(人眼对圆形重心的感知略偏高) |

墨盘减去缺口圆后,两个转角做了圆角。**SVG 里已经是真实的填充路径**(不是描边加圆角连接),可以直接在 Figma、Illustrator、Sketch 中编辑。

### 3.2 墨滴

| 版本 | 用于 | 圆头 | 尖端 | 特点 |
|---|---|---|---|---|
| 标准墨滴 | ≥ 48px、所有矢量母版 | 半径 2.1,圆心 (12, 14.2) | (12, 7.4) | 细长尾巴,两侧凹弧与圆头相切 |
| 小尺寸墨滴 | ≤ 40px | 半径 2.5,圆心 (12, 13.4) | (12, 8.0) | 圆头更大、尾巴更短更粗,防止糊掉 |

墨滴与盘心重心对齐。尖端到缺口之间留有足够间隙,不要为了“更大”而让它们靠近。

### 3.3 颜色规则

- 墨滴永远与墨盘**反色**:深盘用浅滴,浅盘用深滴或底色(镂空)。
- 全图只允许出现“底色、墨盘、墨滴”三种颜色,不加描边、阴影、高光、纹理。
- 渐变只有 `sunrise` 的底色用,且只有一层两色线性渐变(135°,左上到右下)。

---

## 4. 尺寸规则

小尺寸不能靠矢量直接缩小,所以按尺寸分档处理。**位图已经按这个规则分别导出**,不要自己拿大图缩。

### 4.1 应用图标(圆角方块底)

“盘径占比”指墨盘直径占整个图标宽度的比例。

| 输出尺寸 | 盘径占比 | 墨滴 |
|---|---|---|
| ≥ 64 px | 42% | 标准 |
| 41–63 px | 50% | 标准 |
| 21–40 px | 58% | 小尺寸 |
| ≤ 20 px | 68% | 小尺寸 |

底色圆角半径为图标宽度的 22.37%。

### 4.2 其他场景

| 场景 | 盘径占比 | 墨滴 | 说明 |
|---|---|---|---|
| 托盘图标 | 94% | ≤ 24px 小尺寸,其余标准 | 无底,单色,墨滴镂空 |
| Android 自适应前景 | 53.7%(108dp 画布中约 58dp) | 标准 | 圆形安全区为 66dp,已验证落在其内 |
| 通知小图标 | 84% | ≤ 36px 小尺寸,其余标准 | 白色单色,墨滴镂空 |
| 满铺方形(Play Store、iOS、maskable) | 44% | 标准 | 不带圆角,由平台裁切 |

---

## 5. 各端接入(程序同学)

以下路径均相对于 `colorways/<配色>/`,通用素材在 `common/`。

### 5.1 桌面端(Tauri 2,Windows / Linux)

**应用图标**:把 `desktop/tauri-icons/` 的内容复制到 `src-tauri/icons/`:

```
32x32.png   128x128.png   128x128@2x.png   icon.png(512)   icon.ico   icon.icns
```

`tauri.conf.json` 中:

```json
"bundle": {
  "icon": [
    "icons/32x32.png",
    "icons/128x128.png",
    "icons/128x128@2x.png",
    "icons/icon.icns",
    "icons/icon.ico"
  ]
}
```

`icon.ico` 内含 16 / 24 / 32 / 48 / 64 / 128 / 256 七个尺寸,每个尺寸都是单独渲染的,不是缩放得来。`icon.icns`(macOS)按 Apple 模板留了边距;macOS 当前暂缓,先放着。

**Windows 商店磁贴等其他尺寸**:本包没有出。需要时用 Tauri 自带命令,以 `png/app-icon-1024.png` 为源:

```bash
cargo tauri icon colorways/sunrise/png/app-icon-1024.png
```

**Linux**:`desktop/linux/hicolor/` 是标准目录结构,文件名为 `djhx-memo.png`,可直接装到 `/usr/share/icons/hicolor/`。`.desktop` 文件里 `Icon=djhx-memo`。产品名变了就整体重命名。

**托盘图标**(与配色无关,在 `common/tray/`):

| 平台 | 文件 | 用法 |
|---|---|---|
| Windows | `windows/tray-black-*.png`、`tray-black.ico` | 浅色任务栏 |
| Windows | `windows/tray-white-*.png`、`tray-white.ico` | 深色任务栏 |
| Linux | `linux/tray-{black,white}-{22,24,32,48}.png` | 按面板深浅选择 |
| Linux | `linux/djhx-memo-symbolic.svg` | freedesktop 符号图标,由主题自动着色 |
| macOS(暂缓) | `macos-template/trayTemplate.png`、`@2x` | 模板图,系统自动适配深浅 |

> **注意**:Windows 托盘要按**任务栏**的明暗选黑白版,不是按应用自己的明暗主题。两者可以不一致(例如应用浅色、任务栏深色)。任务栏明暗可读注册表 `HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize` 下的 `SystemUsesLightTheme`。

### 5.2 Android(Kotlin + Compose)

把 `android/res/` 合并到 `app/src/main/res/`,覆盖已有的 `ic_launcher*`。

| 文件 | 作用 |
|---|---|
| `mipmap-*dpi/ic_launcher_foreground.png` | 自适应前景(墨盘 + 墨滴),108dp 画布 |
| `mipmap-*dpi/ic_launcher_background.png` | 自适应背景(纯色或渐变) |
| `mipmap-*dpi/ic_launcher_monochrome.png` | Android 13+ 主题图标层,系统会自动着色 |
| `mipmap-*dpi/ic_launcher.png`、`ic_launcher_round.png` | API 25 及以下的旧式图标 |
| `mipmap-anydpi-v26/ic_launcher.xml`、`ic_launcher_round.xml` | 自适应图标声明 |
| `play-store-512.png` | Google Play 商店图标 |

`AndroidManifest.xml`:

```xml
<application
    android:icon="@mipmap/ic_launcher"
    android:roundIcon="@mipmap/ic_launcher_round" ... >
```

**通知小图标**(与配色无关):`common/android/res/drawable-*dpi/ic_stat_notify.png`,白色单色。

```kotlin
.setSmallIcon(R.drawable.ic_stat_notify)
```

> Android 通知图标只看透明度,系统会把它染成单色。所以墨滴是“镂空”而不是“反色填充”,请不要换成彩色。

### 5.3 官网 / Web

`web/` 目录:

```html
<link rel="icon" href="/favicon.ico" sizes="48x48">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/apple-touch-icon-180.png">
<link rel="manifest" href="/manifest.webmanifest">
```

`manifest.webmanifest` 里的图标:

```json
"icons": [
  { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
  { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" },
  { "src": "/icon-maskable-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
]
```

`social-preview-1280x640.png` 可用作 GitHub 仓库的 Social preview 图(Settings → Social preview),目前只有图形,没有文字。

### 5.4 iOS / macOS(暂缓,已备好)

`apple/AppIcon-1024.png`:满铺方形、无透明通道,符合 App Store 要求。未经真机验证。

---

## 6. 注意事项

**可以做**

- 用 `svg/` 下的矢量母版;位图用 `png/` 里按尺寸分好的版本。
- 放在深色或浅色背景上时,选对应配色的整套图标,不要只换背景。
- 图形四周至少留出盘径 1/4 的空白。
- 单色黑版(`common/svg/mark-mono-black.svg`)用于印刷、水印、传真。

**不要做**

- 不要拉伸、旋转、斜切;不要改缺口方向(缺口固定在右上)。
- 不要加阴影、描边、外发光、高光、纹理。
- 不要把大图直接缩到 40px 以下,必须用导出好的小尺寸版本。
- 不要把墨滴换成别的颜色(`vermilion` 这套的朱砂色除外,那是它定义的一部分)。
- 不要让墨滴贴近缺口边缘。
- 不要在图标上叠文字。

**技术提醒**

- SVG 里**没有文字**,没有字体依赖。
- SVG 使用的是填充路径,**没有描边**,在任何软件里缩放都不会出现描边粗细变化。
- 位图导出时先超采样(48px 以下为 8 倍)再用 Lanczos 缩小,所以小尺寸边缘是干净的。
- 所有 PNG 带透明通道(`AppIcon-1024.png` 除外),不内嵌色彩配置文件,按 sRGB 使用。

---

## 7. 待美术确认

我做的是程序化生成,下面几处建议美术过一遍:

1. **16px 和 20px 位图**:现在是按规则自动导出(盘径 68%、小尺寸墨滴)。最规范的做法是美术在像素级微调,对齐像素网格后手工导出。优先检查 `png/app-icon-16.png` 与 `common/tray/windows/tray-*-16.png`。
2. **墨滴的尖端**:16–20px 下尖端会虚成一条灰线,只剩圆头可辨认。这是预期的,但如果想让它更清楚,可以微调小尺寸墨滴的尾巴宽度(`tools/build.py` 里的 `DROP_S`)。
3. **`sunrise` 的渐变**:当前是两色线性渐变。如果品牌要更丰富的朝霞感,可以再调,但要保持只有底色用渐变。
4. **与现有 UI 的协调**:本包没有改动应用内的任何界面颜色。如果选了 `sunrise`,可以考虑把 `#E8734A` 作为界面强调色,这是建议,不在本包范围内。

---

## 8. 本包没有包含的内容

- **字标与锁定组合(横式、竖式)**:产品名还没定。仓库里目前客户端显示 **DJHX Memo**,设计稿里用过「阳墨 / YANGMO」,两者不一致。名字定下来之后再出字标。字体方向建议:中文用思源宋体 SemiBold(字距 +2%),英文用 Inter 或 IBM Plex Sans Medium 全大写(字距 0.18em);宋体的横细竖粗与缺口的笔锋气质一脉相承,不要用黑体。
- **Windows 商店磁贴**:用 `cargo tauri icon` 生成。
- **启动动效**:未制作。建议规范:墨滴由上方短距离落入盘心(约 360ms,ease-out),落定时墨盘向外扩散一圈极淡的涟漪(透明度 8%→0,400ms),全程不超过 600ms,不循环;系统开启“减少动态效果”时直接显示静态图标。
- **仓库品牌文档**:仓库里的 `docs/brand-guidelines.md` 我没能读取,所以文件命名按 Tauri、Android 的通用约定。如果那份文档对文件名、目录有规定,按它调整即可,必要时改 `tools/build.py` 重新生成。

---

## 9. 目录结构

```
.
├── README.md
├── MANIFEST.txt                  全部文件清单
├── preview/
│   ├── colorways-overview.png    5 套配色对比 + 小尺寸
│   └── tray-test.png             托盘在浅色/深色任务栏上的效果
├── tokens/
│   ├── colors.json               配色数据
│   └── colors.css                配色 CSS 变量
├── common/                       与配色无关的素材
│   ├── svg/                      单色矢量(黑、白,标准与小尺寸)
│   ├── tray/                     托盘图标(windows / linux / macos-template)
│   └── android/res/              通知小图标
├── colorways/
│   └── <配色>/                   5 套,结构完全相同
│       ├── svg/                  矢量母版(mark、app-icon、满铺、小尺寸)
│       ├── png/                  应用图标位图 16 – 1024
│       ├── desktop/
│       │   ├── tauri-icons/      Tauri 所需的全部文件
│       │   └── linux/hicolor/    Linux 图标主题目录
│       ├── android/              res/ 与 play-store-512.png
│       ├── apple/                AppIcon-1024.png(暂缓)
│       └── web/                  favicon、apple-touch-icon、PWA、社交预览
└── tools/
    ├── build.py                  重新生成全部素材
    └── render.cjs                SVG 转 PNG(依赖 sharp)
```

## 10. 重新生成

改配色、改几何参数后,可以一键重新生成:

```bash
npm i sharp          # 首次
pip install pillow   # 首次
python3 tools/build.py
```

- 配色在 `build.py` 的 `SCHEMES` 里,加一套配色只需要加一项。
- 几何参数在文件顶部,墨盘、缺口、圆角、墨滴的数值都在那里。
- 重新生成会覆盖 `colorways/`、`common/`、`preview/`、`tokens/`,不会动本文件。

---

## 11. 版本

- **v1**:首版。5 套配色;桌面、Android、Web、托盘、通知全套;矢量母版;生成脚本。
