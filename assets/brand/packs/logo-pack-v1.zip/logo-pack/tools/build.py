#!/usr/bin/env python3
"""
Logo asset builder: "ink disc + eclipse bite + ink drop".

Requirements: Python 3 + Pillow, Node + sharp (npm i sharp).
Usage:  NODE_PATH=$(npm root -g) python3 tools/build.py

Everything is generated from the geometry and colour tables below, so to add a
colourway or tweak a shape, edit this file and re-run. Output goes into the
pack root (colorways/, common/, preview/, tokens/).
"""
import json
import math
import os
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
APP_ID = "djhx-memo"  # Linux icon name; rename if the product name changes

# --------------------------------------------------------------------------
# 1. Geometry (24 x 24 design grid)
# --------------------------------------------------------------------------
DX, DY, R = 12.0, 11.8, 8.2          # ink disc: centre, radius (0.2 optical lift)
CX, CY, RC = 18.93, 4.87, 5.0        # eclipse bite circle (45 deg axis, 9.8 from centre)
FIL = 1.0                            # fillet radius at the two bite corners


def n(v):
    return ("%.3f" % v).rstrip("0").rstrip(".")


def build_disc_path():
    d = math.hypot(CX - DX, CY - DY)
    ux, uy = (CX - DX) / d, (CY - DY) / d
    r1, r2 = R - FIL, RC + FIL
    a = (r1 * r1 - r2 * r2 + d * d) / (2 * d)
    h = math.sqrt(r1 * r1 - a * a)
    bx, by = DX + a * ux, DY + a * uy
    px, py = -uy, ux
    f1 = (bx + h * px, by + h * py)   # lower-right fillet centre
    f2 = (bx - h * px, by - h * py)   # upper-left fillet centre
    a1 = (DX + (f1[0] - DX) * R / r1, DY + (f1[1] - DY) * R / r1)
    a2 = (DX + (f2[0] - DX) * R / r1, DY + (f2[1] - DY) * R / r1)
    b1 = (CX + (f1[0] - CX) * RC / r2, CY + (f1[1] - CY) * RC / r2)
    b2 = (CX + (f2[0] - CX) * RC / r2, CY + (f2[1] - CY) * RC / r2)
    return (
        f"M{n(a2[0])} {n(a2[1])}"
        f"A{n(R)} {n(R)} 0 1 0 {n(a1[0])} {n(a1[1])}"
        f"A{n(FIL)} {n(FIL)} 0 0 0 {n(b1[0])} {n(b1[1])}"
        f"A{n(RC)} {n(RC)} 0 0 1 {n(b2[0])} {n(b2[1])}"
        f"A{n(FIL)} {n(FIL)} 0 0 0 {n(a2[0])} {n(a2[1])}Z"
    )


DISC = build_disc_path()
# Ink drop: round head, concave "fillet" flanks, sharp tip. Standard (>= 48px)
DROP = "M12 7.4C12.1 9.4 12.43 11.82 13.35 12.59A2.1 2.1 0 1 1 10.65 12.59C11.57 11.82 11.9 9.4 12 7.4Z"
# Small-size drop (<= 40px): bigger head, shorter and fatter tail
DROP_S = "M12 8C12.25 9.2 12.46 10.52 13.607 11.485A2.5 2.5 0 1 1 10.393 11.485C11.54 10.52 11.75 9.2 12 8Z"
MARK_VIEWBOX = "3 2.8 18 18"        # tight square around the disc, 0.8 margin
TILE_RADIUS = 0.2237                 # rounded-square corner radius / tile size

# --------------------------------------------------------------------------
# 2. Colourways
# --------------------------------------------------------------------------
SCHEMES = {
    "ink-night": dict(label="墨夜 Ink Night", bg="#0E0F11", disc="#262B33", drop="#F6F1E7", grad=None,
                      note="深色底,墨盘微提亮,墨滴宣纸白。最克制,适合深色系统与深色 UI。"),
    "ink-paper": dict(label="宣纸 Ink Paper", bg="#F7F4EE", disc="#14161A", drop="#F7F4EE", grad=None,
                      note="宣纸底,墨黑盘,墨滴与底同色,像镂空。印谱气质,适合浅色场景与印刷。"),
    "vermilion": dict(label="朱砂 Vermilion", bg="#F7F4EE", disc="#14161A", drop="#C0392B", grad=None,
                      note="宣纸底,墨黑盘,朱砂墨滴。像盖了一枚印,识别度高,红色只占极小面积。"),
    "sunrise": dict(label="朝暾 Sunrise", bg="#E8734A", disc="#14161A", drop="#F6F1E7", grad=("#F2B45C", "#E8734A"),
                    note="暖色渐变底,墨黑盘,最贴近“墨中出日”。主屏上最醒目,唯一用渐变的版本。"),
    "indigo": dict(label="靛青 Indigo", bg="#EEF1F6", disc="#1B2A49", drop="#EEF1F6", grad=None,
                   note="冷灰白底,靛蓝盘,墨滴镂空。偏工具、偏理性,与暖色系统图标区分明显。"),
}


def bg_fill(sch, uid):
    if sch["grad"]:
        defs = (f'<defs><linearGradient id="{uid}" x1="0" y1="0" x2="1" y2="1">'
                f'<stop offset="0" stop-color="{sch["grad"][0]}"/>'
                f'<stop offset="1" stop-color="{sch["grad"][1]}"/></linearGradient></defs>')
        return defs, f"url(#{uid})"
    return "", sch["bg"]


# --------------------------------------------------------------------------
# 3. SVG builders
# --------------------------------------------------------------------------
NS = 'xmlns="http://www.w3.org/2000/svg"'


def disc_frac(size):
    """Share of the tile width taken by the disc diameter, by output size."""
    if size >= 64:
        return 0.42
    if size >= 41:
        return 0.50
    if size >= 21:
        return 0.58
    return 0.68


def tile_svg(S, sch, frac, small, shape="round", inset=0.0):
    defs, fill = bg_fill(sch, "bg")
    t = S * (1 - 2 * inset)
    off = S * inset
    rx = {"round": TILE_RADIUS * t, "full": 0, "circle": t / 2}[shape]
    scale = frac * t / (2 * R)
    tx = S / 2 - 12 * scale
    ty = S / 2 - 12 * scale
    drop = DROP_S if small else DROP
    return (f'<svg {NS} width="{S}" height="{S}" viewBox="0 0 {S} {S}">{defs}'
            f'<rect x="{n(off)}" y="{n(off)}" width="{n(t)}" height="{n(t)}" rx="{n(rx)}" fill="{fill}"/>'
            f'<g transform="translate({n(tx)} {n(ty)}) scale({n(scale)})">'
            f'<path d="{DISC}" fill="{sch["disc"]}"/><path d="{drop}" fill="{sch["drop"]}"/></g></svg>')


def fg_svg(S, sch, frac):
    scale = frac * S / (2 * R)
    tx, ty = S / 2 - DX * scale, S / 2 - DY * scale
    return (f'<svg {NS} width="{S}" height="{S}" viewBox="0 0 {S} {S}">'
            f'<g transform="translate({n(tx)} {n(ty)}) scale({n(scale)})">'
            f'<path d="{DISC}" fill="{sch["disc"]}"/><path d="{DROP}" fill="{sch["drop"]}"/></g></svg>')


def mono_svg(S, color, small, frac):
    """Single-colour mark, ink drop punched out (transparent)."""
    scale = frac * S / (2 * R)
    tx, ty = S / 2 - DX * scale, S / 2 - DY * scale
    drop = DROP_S if small else DROP
    return (f'<svg {NS} width="{S}" height="{S}" viewBox="0 0 {S} {S}">'
            f'<g transform="translate({n(tx)} {n(ty)}) scale({n(scale)})">'
            f'<path fill-rule="evenodd" d="{DISC}{drop}" fill="{color}"/></g></svg>')


def bg_only_svg(S, sch):
    defs, fill = bg_fill(sch, "bg")
    return (f'<svg {NS} width="{S}" height="{S}" viewBox="0 0 {S} {S}">{defs}'
            f'<rect width="{S}" height="{S}" fill="{fill}"/></svg>')


def social_svg(sch):
    W, H = 1280, 640
    defs, fill = bg_fill(sch, "bg")
    scale = 380 / (2 * R)
    tx, ty = W / 2 - DX * scale, H / 2 - DY * scale
    return (f'<svg {NS} width="{W}" height="{H}" viewBox="0 0 {W} {H}">{defs}'
            f'<rect width="{W}" height="{H}" fill="{fill}"/>'
            f'<g transform="translate({n(tx)} {n(ty)}) scale({n(scale)})">'
            f'<path d="{DISC}" fill="{sch["disc"]}"/><path d="{DROP}" fill="{sch["drop"]}"/></g></svg>')


# ---- vector masters (shipped as .svg) ------------------------------------
def master_mark(sch):
    return (f'<svg {NS} viewBox="{MARK_VIEWBOX}" width="512" height="512">'
            f'<title>Logo mark</title><path d="{DISC}" fill="{sch["disc"]}"/>'
            f'<path d="{DROP}" fill="{sch["drop"]}"/></svg>\n')


def master_mono(color, small=False):
    drop = DROP_S if small else DROP
    return (f'<svg {NS} viewBox="{MARK_VIEWBOX}" width="512" height="512">'
            f'<title>Logo mark, single colour</title>'
            f'<path fill-rule="evenodd" d="{DISC}{drop}" fill="{color}"/></svg>\n')


def master_tile(sch, small=False, shape="round", S=1024):
    frac = 0.58 if small else 0.42
    return tile_svg(S, sch, frac, small, shape) + "\n"


# --------------------------------------------------------------------------
# 4. Rendering via Node sharp
# --------------------------------------------------------------------------
JOBS = []


def job(out, svg, w, h=None, flatten=None):
    h = h or w
    big = max(w, h)
    ss = 8 if big <= 64 else 4 if big <= 256 else 2
    JOBS.append(dict(out=str(out), svg=svg, w=w, h=h, ss=ss, flatten=flatten))


def run_jobs():
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as fh:
        json.dump(JOBS, fh)
        path = fh.name
    env = dict(os.environ)
    if "NODE_PATH" not in env:
        env["NODE_PATH"] = subprocess.check_output(["npm", "root", "-g"], text=True).strip()
    subprocess.check_call(["node", str(ROOT / "tools" / "render.cjs"), path], env=env)
    os.unlink(path)


# --------------------------------------------------------------------------
# 5. Containers
# --------------------------------------------------------------------------
def write_ico(path, items):
    items = sorted(items)
    head = struct.pack("<HHH", 0, 1, len(items))
    off = 6 + 16 * len(items)
    entries, blob = b"", b""
    for size, data in items:
        w = 0 if size >= 256 else size
        entries += struct.pack("<BBBBHHII", w, w, 0, 0, 1, 32, len(data), off + len(blob))
        blob += data
    Path(path).write_bytes(head + entries + blob)


def write_icns(path, items):
    body = b"".join(t.encode() + struct.pack(">I", 8 + len(b)) + b for t, b in items)
    Path(path).write_bytes(b"icns" + struct.pack(">I", 8 + len(body)) + body)


def read(p):
    return Path(p).read_bytes()


def put(p, text):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


def cp(src, dst):
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dst)


# --------------------------------------------------------------------------
# 6. Plan everything
# --------------------------------------------------------------------------
PNG_SIZES = [16, 20, 22, 24, 32, 40, 48, 64, 96, 128, 192, 256, 512, 1024]
DENS = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
MAC_SIZES = [16, 32, 64, 128, 256, 512, 1024]
TMP = Path(tempfile.mkdtemp(prefix="logo-tmp-"))


def plan_colorway(name, sch):
    base = ROOT / "colorways" / name

    # vector masters
    put(base / "svg/mark.svg", master_mark(sch))
    put(base / "svg/app-icon.svg", master_tile(sch))
    put(base / "svg/app-icon-small.svg", master_tile(sch, small=True, S=256))
    put(base / "svg/app-icon-fullbleed.svg", master_tile(sch, shape="full"))
    put(base / "web/favicon.svg", tile_svg(64, sch, 0.58, True) + "\n")

    # generic rounded-tile PNG set (desktop / web / docs)
    for N in PNG_SIZES:
        job(base / f"png/app-icon-{N}.png", tile_svg(N, sch, disc_frac(N), N <= 40), N)

    # macOS icns sources (deferred platform; tile inset per Apple template)
    for N in MAC_SIZES:
        t = N * 0.804
        job(TMP / name / f"mac-{N}.png", tile_svg(N, sch, disc_frac(t), t <= 40, inset=0.098), N)

    # Android
    res = base / "android/res"
    for dn, d in DENS.items():
        a = int(round(108 * d))
        l = int(round(48 * d))
        job(res / f"mipmap-{dn}/ic_launcher_foreground.png", fg_svg(a, sch, 0.537), a)
        job(res / f"mipmap-{dn}/ic_launcher_background.png", bg_only_svg(a, sch), a)
        job(res / f"mipmap-{dn}/ic_launcher_monochrome.png", mono_svg(a, "#000000", False, 0.537), a)
        job(res / f"mipmap-{dn}/ic_launcher.png", tile_svg(l, sch, disc_frac(l), l <= 40), l)
        job(res / f"mipmap-{dn}/ic_launcher_round.png",
            tile_svg(l, sch, min(disc_frac(l) * 1.1, 0.7), l <= 40, shape="circle"), l)
    adaptive = ('<?xml version="1.0" encoding="utf-8"?>\n'
                '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
                '    <background android:drawable="@mipmap/ic_launcher_background"/>\n'
                '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
                '    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>\n'
                '</adaptive-icon>\n')
    put(res / "mipmap-anydpi-v26/ic_launcher.xml", adaptive)
    put(res / "mipmap-anydpi-v26/ic_launcher_round.xml", adaptive)
    job(base / "android/play-store-512.png", tile_svg(512, sch, 0.44, False, shape="full"), 512)

    # Apple (deferred): full-bleed, no alpha
    job(base / "apple/AppIcon-1024.png", tile_svg(1024, sch, 0.44, False, shape="full"), 1024, flatten=sch["bg"])

    # Web
    job(base / "web/apple-touch-icon-180.png", tile_svg(180, sch, 0.44, False, shape="full"), 180,
        flatten=sch["bg"])
    job(base / "web/icon-maskable-512.png", tile_svg(512, sch, 0.44, False, shape="full"), 512)
    job(base / "web/social-preview-1280x640.png", social_svg(sch), 1280, 640)


def post_colorway(name, sch):
    base = ROOT / "colorways" / name
    p = lambda N: base / f"png/app-icon-{N}.png"

    # Tauri icons
    tauri = base / "desktop/tauri-icons"
    cp(p(32), tauri / "32x32.png")
    cp(p(128), tauri / "128x128.png")
    cp(p(256), tauri / "128x128@2x.png")
    cp(p(512), tauri / "icon.png")
    write_ico(tauri / "icon.ico", [(N, read(p(N))) for N in (16, 24, 32, 48, 64, 128, 256)])
    m = lambda N: read(TMP / name / f"mac-{N}.png")
    write_icns(tauri / "icon.icns", [
        ("icp4", m(16)), ("icp5", m(32)), ("icp6", m(64)), ("ic07", m(128)), ("ic08", m(256)),
        ("ic09", m(512)), ("ic10", m(1024)), ("ic11", m(32)), ("ic12", m(64)), ("ic13", m(256)),
        ("ic14", m(512))])

    # Linux hicolor
    for N in (16, 22, 24, 32, 48, 64, 128, 256, 512):
        cp(p(N), base / f"desktop/linux/hicolor/{N}x{N}/apps/{APP_ID}.png")
    cp(base / "svg/app-icon.svg", base / f"desktop/linux/hicolor/scalable/apps/{APP_ID}.svg")

    # Web
    web = base / "web"
    cp(p(16), web / "favicon-16.png")
    cp(p(32), web / "favicon-32.png")
    cp(p(192), web / "icon-192.png")
    cp(p(512), web / "icon-512.png")
    write_ico(web / "favicon.ico", [(N, read(p(N))) for N in (16, 32, 48)])


def plan_common():
    com = ROOT / "common"
    put(com / "svg/mark-mono-black.svg", master_mono("#000000"))
    put(com / "svg/mark-mono-white.svg", master_mono("#FFFFFF"))
    put(com / "svg/mark-mono-small-black.svg", master_mono("#000000", small=True))
    put(com / "svg/mark-mono-small-white.svg", master_mono("#FFFFFF", small=True))

    for cname, color in (("black", "#000000"), ("white", "#FFFFFF")):
        for N in (16, 20, 24, 32, 48, 64):
            job(com / f"tray/windows/tray-{cname}-{N}.png", mono_svg(N, color, N <= 24, 0.94), N)
        for N in (22, 24, 32, 48):
            job(com / f"tray/linux/tray-{cname}-{N}.png", mono_svg(N, color, N <= 24, 0.94), N)
    job(com / "tray/macos-template/trayTemplate.png", mono_svg(18, "#000000", True, 0.94), 18)
    job(com / "tray/macos-template/trayTemplate@2x.png", mono_svg(36, "#000000", False, 0.94), 36)
    # freedesktop "symbolic" icon (recoloured by the desktop theme)
    sym = mono_svg(16, "#bebebe", True, 0.94).replace('width="16" height="16" ', "")
    put(com / f"tray/linux/{APP_ID}-symbolic.svg", sym + "\n")

    for dn, d in DENS.items():
        N = int(round(24 * d))
        job(com / f"android/res/drawable-{dn}/ic_stat_notify.png", mono_svg(N, "#FFFFFF", N <= 36, 0.84), N)


def post_common():
    com = ROOT / "common"
    for cname in ("black", "white"):
        write_ico(com / f"tray/windows/tray-{cname}.ico",
                  [(N, read(com / f"tray/windows/tray-{cname}-{N}.png")) for N in (16, 20, 24, 32, 48, 64)])


# --------------------------------------------------------------------------
# 7. Previews, tokens, manifest
# --------------------------------------------------------------------------
def font(size, bold=False):
    for path in ("/usr/share/fonts/opentype/noto/NotoSansCJK-%s.ttc" % ("Bold" if bold else "Regular"),
                 "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"):
        if os.path.exists(path):
            try:
                return ImageFont.truetype(path, size, index=2)
            except Exception:
                pass
    return ImageFont.load_default()


def previews():
    pv = ROOT / "preview"
    pv.mkdir(exist_ok=True)
    names = list(SCHEMES)
    colw, pad = 300, 30
    W = colw * len(names) + pad * 2
    H = 540
    sheet = Image.new("RGB", (W, H), "#D5D3CE")
    dr = ImageDraw.Draw(sheet)
    for i, name in enumerate(names):
        x0 = pad + i * colw
        big = Image.open(ROOT / f"colorways/{name}/png/app-icon-256.png").convert("RGBA")
        sheet.paste(big, (x0 + 22, 40), big)
        dr.text((x0 + 22, 310), SCHEMES[name]["label"], fill="#1A1A1A", font=font(18, True))
        dr.text((x0 + 22, 338), name, fill="#555", font=font(14))
        x = x0 + 22
        for N in (64, 48, 32, 24, 16):
            im = Image.open(ROOT / f"colorways/{name}/png/app-icon-{N}.png").convert("RGBA")
            sheet.paste(im, (x, 400 + (64 - N)), im)
            dr.text((x, 478), str(N), fill="#555", font=font(12))
            x += N + 18
    sheet.save(pv / "colorways-overview.png")

    # tray test: each icon at 1x..4x on light and dark taskbars (nearest-neighbour zoom)
    com = ROOT / "common/tray/windows"
    sizes = (16, 20, 24, 32)
    T = Image.new("RGB", (760, 330), "#888")
    td = ImageDraw.Draw(T)
    for row, (bgc, cname, title) in enumerate((("#F3F3F3", "black", "亮色任务栏 → tray-black"),
                                               ("#202020", "white", "暗色任务栏 → tray-white"))):
        y0 = 20 + row * 160
        td.rectangle([20, y0, 740, y0 + 140], fill=bgc)
        td.text((32, y0 + 8), title, fill="#222" if row == 0 else "#EEE", font=font(14))
        x = 40
        for N in sizes:
            im = Image.open(com / f"tray-{cname}-{N}.png").convert("RGBA")
            T.paste(im, (x, y0 + 50), im)
            z = im.resize((N * 4, N * 4), Image.NEAREST)
            T.paste(z, (x + 120, y0 + 30), z) if N == 16 else None
            td.text((x, y0 + 50 + N + 6), f"{N}px", fill="#666", font=font(11))
            x += N + 24
    # zoomed row for 24 and 32 as well
    T.save(pv / "tray-test.png")


def tokens():
    out = {k: {kk: vv for kk, vv in v.items() if kk != "note"} for k, v in SCHEMES.items()}
    put(ROOT / "tokens/colors.json", json.dumps(out, ensure_ascii=False, indent=2) + "\n")
    css = [":root {"]
    for k, v in SCHEMES.items():
        css.append(f"  --logo-{k}-bg: {v['bg']};")
        css.append(f"  --logo-{k}-disc: {v['disc']};")
        css.append(f"  --logo-{k}-drop: {v['drop']};")
        if v["grad"]:
            css.append(f"  --logo-{k}-bg-from: {v['grad'][0]};")
            css.append(f"  --logo-{k}-bg-to: {v['grad'][1]};")
    css.append("}")
    put(ROOT / "tokens/colors.css", "\n".join(css) + "\n")


def manifest():
    lines = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and p.name not in ("MANIFEST.txt",):
            lines.append(f"{p.relative_to(ROOT).as_posix()}  ({p.stat().st_size:,} B)")
    put(ROOT / "MANIFEST.txt", "\n".join(lines) + "\n")


def main():
    for name, sch in SCHEMES.items():
        plan_colorway(name, sch)
    plan_common()
    run_jobs()
    for name, sch in SCHEMES.items():
        post_colorway(name, sch)
    post_common()
    previews()
    tokens()
    shutil.rmtree(TMP, ignore_errors=True)
    manifest()
    print("done:", len(JOBS), "rasters")


if __name__ == "__main__":
    main()
