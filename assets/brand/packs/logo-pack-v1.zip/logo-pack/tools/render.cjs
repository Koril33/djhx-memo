// Rasterises SVG jobs to PNG with sharp (librsvg). Called by build.py.
// Each job is supersampled (job.ss) and then downsampled with Lanczos so that
// small sizes (16-48 px) stay crisp. Requires: npm i sharp
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

const jobs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const queue = jobs.slice();

async function worker() {
  while (queue.length) {
    const j = queue.shift();
    let img = sharp(Buffer.from(j.svg), { density: 72 * j.ss });
    img = img.resize(j.w, j.h, { kernel: 'lanczos3', fit: 'fill' });
    if (j.flatten) img = img.flatten({ background: j.flatten }).removeAlpha();
    fs.mkdirSync(path.dirname(j.out), { recursive: true });
    await img.png({ compressionLevel: 9 }).toFile(j.out);
  }
}

Promise.all(Array.from({ length: 6 }, worker))
  .then(() => console.log('rendered', jobs.length))
  .catch((e) => { console.error(e); process.exit(1); });
